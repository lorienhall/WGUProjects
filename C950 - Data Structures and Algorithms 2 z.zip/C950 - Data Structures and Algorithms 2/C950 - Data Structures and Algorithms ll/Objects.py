
# Object creation
first_status = {}
second_status = {}
third_status = {}
distance_list = []
address_list = []
unloaded_package_list = []
all_list = []
load_list_1 = [20,21,28,4,40,1,7,29,10,3,30,8,5,37,38,9]  #truck 2
load_list_2 = [14,15,16,34,25,26,19,12,36,6,17,31,32,2,33]  #truck 1
load_list_3 = [24,23,11,18,22,35,27,13,39]  #truck 1







