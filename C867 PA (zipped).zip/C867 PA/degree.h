#pragma once


#include <string>
using namespace std;

const enum class DegreeProgram { SECURITY, NETWORK, SOFTWARE };

//Parallel array
const static string degreeProgramStrings[] = { "SECURITY", "NETWORK", "SOFTWARE" };

